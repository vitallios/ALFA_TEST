<script setup>

</script>
<template>
 <footer class="absolute bottom-0 w-full text-center bg-[#FAFAFA] py-[30px]">
  <p>all rights reserved</p>
 </footer>
</template>

